package contacloud.dplicencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DpLicenciasApplicationTests {

    @Test
    void contextLoads() {
    }

}
